package com.cs336.Bean;

/**
 * @Author: Wangjc
 * @Date: 2021-12-03 17:48:05
 * @Version:v1.0
 * @Description: Aircraft
 */

public class Aircraft {
    private int aircraft_number;
    private String id;
    private int total_seats;

    public int getAircraft_number() {
        return aircraft_number;
    }

    public void setAircraft_number(int aircraft_number) {
        this.aircraft_number = aircraft_number;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getTotal_seats() {
        return total_seats;
    }

    public void setTotal_seats(int total_seats) {
        this.total_seats = total_seats;
    }
}
