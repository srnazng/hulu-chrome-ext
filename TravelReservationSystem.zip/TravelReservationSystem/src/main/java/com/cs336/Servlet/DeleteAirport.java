package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/deleteAirport")
public class DeleteAirport extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "delete from airport where id = " + "''"+ id+"'";

        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("delete success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("delete failed");
        }
    }
}
