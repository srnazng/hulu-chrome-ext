package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;
import com.cs336.utils.IdUtils;
import org.apache.taglibs.standard.lang.jstl.GreaterThanOrEqualsOperator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

/**
 * @Author: Wangjc
 * @Date: 2021-12-03 15:41:13
 * @Version:v1.0
 * @Description: ReserverServlet
 */
@WebServlet("/reserve")
public class ReserveServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String airline_id = req.getParameter("airline_id");
        String flight_number = req.getParameter("flight_number");
        String account_num = req.getParameter("account_num");
        String clazz = req.getParameter("class");
        String free = req.getParameter("free");
        System.out.println(airline_id);
        System.out.println(flight_number);
        System.out.println(account_num);
        System.out.println(clazz);
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "insert into reserve_ticket values("
                + IdUtils.getOrderCode()+","
                + account_num +","
                + "'"+clazz + "'"+",now(),"
                + free+","
                + free+");";
        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i>0){
                resp.getWriter().write("reverse success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("reverse failed!!!");

        }


    }
}
