package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @Author: Wangjc
 * @Date: 2021-12-03 18:44:53
 * @Version:v1.0
 * @Description: InsertAircraft
 */
@WebServlet("/updateAircraft")
public class UpdateAircraft extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String aircraft_number = req.getParameter("aircraft_number");
        req.setAttribute("aircraft_number",aircraft_number);
        req.getRequestDispatcher("CustomerRep/updateAircraft.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String aircraft_number = req.getParameter("aircraft_number");
        String old_aircraft_number = req.getParameter("old_aircraft_number");
        String id = req.getParameter("id");
        String total_seats = req.getParameter("total_seats");
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "update owns_aircraft "
                + "set aircraft_number = " + aircraft_number + " and "
                + "id = " + "'" + id + "'" + " and "
                + " total_seats = " + total_seats
                + " where aircraft_number="+old_aircraft_number;
        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("Update success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("  Update failed!!!");

        }
    }
}
