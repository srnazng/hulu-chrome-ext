package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/insertAircraft")
public class InsertAircraft extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String aircraft_number = req.getParameter("aircraft_number");
        String id = req.getParameter("id");
        String total_seats = req.getParameter("total_seats");
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "insert into owns_aircraft values("
                + aircraft_number + ','
                + "'" + id + "'" + ','
                + total_seats +
                ')';
        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("Insert success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write(" this aircraft_number is exist!!!");

        }
    }
}
