package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @Author:
 * @Date: 2021-12-03 15:41:13
 * @Version:v1.0
 * @Description: ReserverServlet
 */
@WebServlet("/updateFlight")
public class updateFlightServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String airline_id = req.getParameter("airline_id");
        String flight_number = req.getParameter("flight_number");
        String aircraft_number = req.getParameter("aircraft_number");
        String depart_airport_id = req.getParameter("depart_airport_id");
        String destination_airport_id = req.getParameter("destination_airport_id");
        String departure_time = req.getParameter("departure_time");
        String arrival_time = req.getParameter("arrival_time");
        String duration = req.getParameter("duration");
        String business_fare = req.getParameter("business_fare");
        String economy_fare = req.getParameter("economy_fare");
        String first_class_fare = req.getParameter("first_class_fare");
        System.out.println(airline_id);
        System.out.println(flight_number);
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "update  flight set "
                + "airline_id = " + "'" + airline_id + "'" + " , "
                + "flight_number = " + flight_number + " , "
                + "aircraft_number = " + aircraft_number + " , "
                + "depart_airport_id = " + "'" + depart_airport_id + "'" + " , "
                + "destination_airport_id = " + "'" + destination_airport_id + "'" + " , "
                + "departure_time = " + "'" + departure_time + "'" + " , "
                + "arrival_time = " + "'" + arrival_time + "'" + " , "
                + "duration = " + duration + " , "
                + "business_fare = " + business_fare + " , "
                + "economy_fare = " + economy_fare + " , "
                + "first_class_fare = " + first_class_fare
                + " where airline_id = " + "'" + airline_id + "'" + " and "
                + " flight_number = " + flight_number ;
        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("Update success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("Update failed!!!");

        }
    }
}
