package com.cs336.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * ID生成器工具类
 * 
 * @author ruoyi
 */
public class IdUtils
{
    //订单编号前缀
    public static final String PREFIX = "";
    //订单编号后缀（核心部分）
    private static long code;
    /**
     * 获取随机UUID
     * 
     * @return 随机UUID
     */
    public static String randomUUID()
    {
        return UUID.randomUUID().toString();
    }



    public static synchronized String getOrderCode() {
        code++;
        String str = new SimpleDateFormat("MMddHHmmss").format(new Date());

        return PREFIX + str;
    }
}
