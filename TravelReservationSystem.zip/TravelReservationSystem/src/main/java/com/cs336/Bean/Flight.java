package com.cs336.Bean;

/**
 * @Author: Wangjc
 * @Date: 2021-12-03 15:28:26
 * @Version:v1.0
 * @Description: Flights
 */

public class Flight {
    private String airline_id;
    private String flight_number;
    private String aircraft_number;
    private String depart_airport_id;
    private String destination_airport_id;
    private String departure_time;
    private String arrival_time;
    private String duration;
    private String economy_fare;
    private String business_fare;
    private String first_class_fare;

    public String getEconomy_fare() {
        return economy_fare;
    }

    public void setEconomy_fare(String economy_fare) {
        this.economy_fare = economy_fare;
    }

    public String getAirline_id() {
        return airline_id;
    }

    public void setAirline_id(String airline_id) {
        this.airline_id = airline_id;
    }

    public String getFlight_number() {
        return flight_number;
    }

    public void setFlight_number(String flight_number) {
        this.flight_number = flight_number;
    }

    public String getAircraft_number() {
        return aircraft_number;
    }

    public void setAircraft_number(String aircraft_number) {
        this.aircraft_number = aircraft_number;
    }

    public String getDepart_airport_id() {
        return depart_airport_id;
    }

    public void setDepart_airport_id(String depart_airport_id) {
        this.depart_airport_id = depart_airport_id;
    }

    public String getDestination_airport_id() {
        return destination_airport_id;
    }

    public void setDestination_airport_id(String destination_airport_id) {
        this.destination_airport_id = destination_airport_id;
    }

    public String getDeparture_time() {
        return departure_time;
    }

    public void setDeparture_time(String departure_time) {
        this.departure_time = departure_time;
    }

    public String getArrival_time() {
        return arrival_time;
    }

    public void setArrival_time(String arrival_time) {
        this.arrival_time = arrival_time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getBusiness_fare() {
        return business_fare;
    }

    public void setBusiness_fare(String business_fare) {
        this.business_fare = business_fare;
    }

    public String getFirst_class_fare() {
        return first_class_fare;
    }

    public void setFirst_class_fare(String first_class_fare) {
        this.first_class_fare = first_class_fare;
    }
}
