package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;
import com.cs336.utils.DateUtils;
import com.cs336.utils.IdUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

@WebServlet("/insertFlight")
public class InsertFlightServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String airline_id = req.getParameter("airline_id");
        String flight_number = req.getParameter("flight_number");
        String aircraft_number = req.getParameter("aircraft_number");
        String depart_airport_id = req.getParameter("depart_airport_id");
        String destination_airport_id = req.getParameter("destination_airport_id");
        String departure_time = req.getParameter("departure_time");
        String arrival_time = req.getParameter("arrival_time");
        String duration = req.getParameter("duration");
        String business_fare = req.getParameter("business_fare");
        String economy_fare = req.getParameter("economy_fare");
        String first_class_fare = req.getParameter("first_class_fare");
        int economy_seats_available = Integer.parseInt(req.getParameter("economy_seats"));
        int business_seats_available = Integer.parseInt(req.getParameter("business_seats"));
        int first_class_seats_available = Integer.parseInt(req.getParameter("first_class_seats"));
        
        Calendar start = Calendar.getInstance();
        start.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
        start.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
        start.set(Calendar.DAY_OF_MONTH, 1);
        System.out.println(start.get(Calendar.DAY_OF_WEEK));
        
        Calendar end = Calendar.getInstance(); // exclusive
        end.set(Calendar.MONTH, Integer.parseInt(req.getParameter("end_month")) - 1);
        end.set(Calendar.YEAR, Integer.parseInt(req.getParameter("end_year")));
        end.add(Calendar.MONTH, 1);
        start.set(Calendar.DAY_OF_MONTH, 1);
 

        System.out.println(airline_id);
        System.out.println(flight_number);
        ApplicationDB db = new ApplicationDB();
        Connection con = db.getConnection();
        String sql = "insert into flight values("
                + "'" + airline_id + "'" + ','
                + flight_number + ','
                + aircraft_number + ','
                + "'" + depart_airport_id + "'" + ','
                + "'" + destination_airport_id + "'" + ','
                + "'" + departure_time + "'" + ','
                + "'" + arrival_time + "'" + ','
                + duration + ','
                + business_fare + ','
                + economy_fare + ','
                + first_class_fare + ')';
        System.out.println(sql);
        System.err.println(sql);
        PreparedStatement ps = null;

        try {
            ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("Insert success!!!");
            }
            
            // insert into operation days
            if(req.getParameter("Sunday") != null) {
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Sunday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 1) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Monday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Monday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 2) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        	System.out.println(c);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Tuesday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Tuesday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 3) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Wednesday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Wednesday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 4) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Thursday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Thursday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 5) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Friday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Friday");
						
				ps.executeUpdate();

				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 6) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            if(req.getParameter("Saturday") != null) {			
				String res = "insert into Operation_days (airline_id, flight_number, day) values (?, ?, ?);";
				
				//Create a Prepared SQL statement allowing you to introduce the parameters of the query
				ps = con.prepareStatement(res);
				
				//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
				ps.setString(1, airline_id);
				ps.setString(2, flight_number);
				ps.setString(3,"Saturday");
						
				ps.executeUpdate();
				
				Calendar c = Calendar.getInstance();
		        c.set(Calendar.MONTH, Integer.parseInt(req.getParameter("start_month")) - 1);
		        c.set(Calendar.YEAR, Integer.parseInt(req.getParameter("start_year")));
		        c.set(Calendar.DAY_OF_MONTH, 1);
		        
		        while(c.get(Calendar.DAY_OF_WEEK) != 7) {
		        	c.add(Calendar.DAY_OF_MONTH, 1);
		        }
				
				while(c.before(end)) {
					res = "insert into Flight_instance (airline_id, flight_number, departure_date, business_seats_available, economy_seats_available, first_class_seats_available) values (?, ?, ?, ?, ?, ?);";
					
					//Create a Prepared SQL statement allowing you to introduce the parameters of the query
					ps = con.prepareStatement(res);
					
					String departure_date = c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH);
					System.out.println(departure_date);
					
					//Add parameters of the query. Start with 1, the 0-parameter is the INSERT statement itself
					ps.setString(1, airline_id);
					ps.setString(2, flight_number);
					ps.setString(3, departure_date);
					ps.setInt(4, business_seats_available);
					ps.setInt(5, economy_seats_available);
					ps.setInt(6, first_class_seats_available);
					
					ps.executeUpdate();
					
					c.add(Calendar.DAY_OF_MONTH, 7);
				}
            }
            
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("Insert failed!!!");
        }
        
    }
}
