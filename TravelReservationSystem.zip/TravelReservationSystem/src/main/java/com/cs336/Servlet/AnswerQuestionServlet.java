package com.cs336.Servlet;

import com.cs336.pkg.ApplicationDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/answerQuestion")
public class AnswerQuestionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String answer = req.getParameter("answer");
        String question_text = req.getParameter("question_text");
        ApplicationDB applicationDB = new ApplicationDB();
        Connection con = applicationDB.getConnection();
        String sql = "insert into answer values ( " + "'" + question_text + "'," + "'" + answer + "')";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            int i = ps.executeUpdate();
            if (i > 0) {
                resp.getWriter().write("Answer success!!!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            resp.getWriter().write("Answer failed!!!");
        }
    }
}
